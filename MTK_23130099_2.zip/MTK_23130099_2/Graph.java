package MTK_23130099_2;

public abstract class Graph {
	protected int[][] graph;
	public Graph(int n) {
		graph = new int[n][n];
	}
	public abstract void addEdge(int a, int b);
	public abstract void removeEdge(int a, int b) throws Exception;
	public abstract int allEdge();
	public void print() {
		for (int i = 0 ; i < graph.length ; i++) {
			for (int j = 0 ; j < graph[i].length ; j++) {
				System.out.print(graph[i][j]);
			}
			System.out.println();
		}
	}
}
