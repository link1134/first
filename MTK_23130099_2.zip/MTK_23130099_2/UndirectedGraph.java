package MTK_23130099_2;

public class UndirectedGraph extends Graph{

	public UndirectedGraph(int n) {
		super(n);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void addEdge(int a, int b) {
		// TODO Auto-generated method stub
		this.graph[a][b]++;
		if (a != b) {
			this.graph[b][a]++;
		}
	}

	@Override
	public void removeEdge(int a, int b) {
		// TODO Auto-generated method stub
		this.graph[a][b]--;
		if (a != b) {
			this.graph[b][a]--;
		}
	}

	@Override
	public int allEdge() {
		// TODO Auto-generated method stub
		int result = 0;
		for (int i = 0 ; i < this.graph.length ; i++) {
			for (int j = 0 ; j < graph[i].length ; j++) {
				result += graph[i][j];
			}
			if (graph[i][i] != 0) {
				result += graph[i][i]*2;
			}
		}
		return result/2;
	}
	public int degree(int n) {
		int result = 0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += graph[n][i];
		}
		return result;
	}
}
