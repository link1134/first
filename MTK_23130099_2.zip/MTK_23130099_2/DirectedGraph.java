package MTK_23130099_2;

public class DirectedGraph extends Graph{

	public DirectedGraph(int n) {
		super(n);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addEdge(int a, int b) {
		// TODO Auto-generated method stub
		this.graph[a][b]++;
	}

	@Override
	public void removeEdge(int a, int b) {
		// TODO Auto-generated method stub
		this.graph[a][b]--;
	}

	@Override
	public int allEdge() {
		int result = 0;
		for (int i = 0; i < graph.length ; i++) {
			result += outDegree(i);
		}
		return result;
	}
	public int outDegree(int n) {
		int result = 0;
		for (int i = 0 ; i < graph[n].length ; i++) {
			result += graph[n][i];
		}
		return result;
	}
	public int inDegree(int n) {
		int result = 0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += graph[i][n];
		}
		return result;
	}
}
