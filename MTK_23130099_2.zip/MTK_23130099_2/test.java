package MTK_23130099_2;

public class test {
	public static void main(String[] args) {
		UndirectedGraph graph1 = new UndirectedGraph(3);
		graph1.addEdge(0, 1);
		graph1.addEdge(0, 1);
		graph1.addEdge(0, 1);
		graph1.addEdge(1, 1);
		graph1.removeEdge(0, 1);
		graph1.print();
		System.out.println(graph1.degree(1));
		System.out.println(graph1.allEdge());
		System.out.println("DirectedGRaph test");
		DirectedGraph graph2 = new DirectedGraph(3);
		graph2.addEdge(0, 0);
		graph2.addEdge(0, 0);
		graph2.addEdge(1, 1);
		graph2.addEdge(2, 1);
		graph2.print();
		System.out.println(graph2.outDegree(1));
		System.out.println(graph2.inDegree(1));
		System.out.println(graph2.allEdge());
		graph2.removeEdge(2, 1);
		graph2.print();
	}
}
