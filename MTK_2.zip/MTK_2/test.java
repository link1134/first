package MTK_2;

public class test {
	public static void main(String[] args) {
		UndirectedGraph u1 = new UndirectedGraph(3); //Đồ thị vô hướng test
		u1.addEdge(0, 1);
		u1.addEdge(0, 2);
		u1.addEdge(1, 2);
		u1.print();
		System.out.println(u1.degree(1));
		System.out.println(u1.allEdge());
		System.out.println();
		DirectedGraph d1 = new DirectedGraph(3); //Đồ thị có hướng test
		d1.addEdge(0, 2);
		d1.addEdge(2, 1);
		d1.addEdge(1, 0);
		d1.print();
		System.out.println(d1.outDegree(0));
		System.out.println(d1.allEdge());
	}
}
