package MTK_2;

public class DirectedGraph extends Graph {

	public DirectedGraph(int size) {
		super(size);
		// TODO Auto-generated constructor stub
	}

	public void addEdge(int a, int b) {
		if (a >= 0 && a < graph.length && b >= 0 && b < graph.length) {
			this.graph[a][b]++;
		}
	}

	@Override
	public void removeEdge(int a, int b) {
		// TODO Auto-generated method stub
		if (a >= 0 && a < graph.length && b >= 0 && b < graph.length && graph[a][b] > 0) {
			this.graph[a][b]--;
		}
	}
	public int outDegree(int n) {
		int result =0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += graph[n][i];
		}
		return result;
	}
	public int inDegree(int n) {
		int result = 0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += graph[i][n];
		}
		return result;
	}

	@Override
	public int allEdge() {
		// TODO Auto-generated method stub
		int result = 0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += outDegree(i);
		}
		return result;
	}
}
