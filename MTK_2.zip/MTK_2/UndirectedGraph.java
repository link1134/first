package MTK_2;

public class UndirectedGraph extends Graph {

	public UndirectedGraph(int size) {
		super(size);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addEdge(int a, int b) {
		// TODO Auto-generated method stub
		if (a >= 0 && a < graph.length && b >= 0 && b < graph.length && a != b) {
			this.graph[a][b]++;
			this.graph[b][a]++;
		} else
			this.graph[a][b]++;
	}

	@Override
	public void removeEdge(int a, int b) {
		// TODO Auto-generated method stub
		if (a >= 0 && a < graph.length && b >= 0 && b < graph.length && a != b && graph[a][b] > 0) {
			this.graph[a][b]--;
			this.graph[b][a]--;
		} else
			this.graph[a][b]--;
	}

	public int degree(int n) {
		int result = 0;
		for (int i = 0; i < graph.length; i++) {
			result += graph[n][i];
		}
		if (graph[n][n] > 0) {
			result += graph[n][n];
		}
		return result;
	}

	@Override
	public int allEdge() {
		// TODO Auto-generated method stub
		int result = 0;
		for (int i = 0 ; i < graph.length ; i++) {
			result += degree(i);
		}
		return result/2;
	}
}
