package MTK_2;

import java.util.LinkedList;
import java.util.Queue;

public abstract class Graph {
	protected int[][] graph;
	protected int size;

	public Graph(int size) {
		super();
		this.graph = new int[size][size];
		this.size = size;
	}

	public abstract void addEdge(int a, int b);

	public abstract void removeEdge(int a, int b);

	public void print() {
		for (int i = 0; i < graph.length; i++) {
			for (int j = 0; j < graph[i].length; j++) {
				System.out.print(graph[i][j] + "\t");
			}
			System.out.println();
		}
	}

	public abstract int allEdge();

	public void BFS(int s) {
		Queue<Integer> q = new LinkedList<Integer>(); // Tạo queue
		boolean[] b = new boolean[graph.length]; // Một mảng boolean để đánh dấu đỉnh nào đã qua và đỉnh nào chưa qua
		q.add(s);
		b[s] = true;
		while (!q.isEmpty()) {
			int n = q.poll();
			System.out.println(n + " ");
			for (int i = 0; i < graph.length; i++) {
				if (graph[n][i] != 0 && b[i] == false) {
					q.add(i);
					b[i] = true;
				}
			}
		}
	}

	public boolean isConnection() {
		boolean result = true;
		int s = 0;
		Queue<Integer> q = new LinkedList<Integer>(); // Tạo queue
		boolean[] b = new boolean[graph.length]; // Một mảng boolean để đánh dấu đỉnh nào đã qua và đỉnh nào chưa qua
		q.add(s);
		b[s] = true;
		while (!q.isEmpty()) {
			int n = q.poll();
			System.out.println(n + " ");
			for (int i = 0; i < graph.length; i++) {
				if (graph[n][i] != 0 && b[i] == false) {
					q.add(i);
					b[i] = true;
				}
			}
		}
		for (int i = 0; i < graph.length; i++) {
			if (b[i] != true) {
				result = false;
			}
		}
		return result;
	}

	public void DFS(int s, boolean[] b) {
		b[s] = true;
		System.out.print(s + "\t");
		for (int i = 0; i < graph.length; i++) {
			if (graph[s][i] != 0 && b[i] != true) {
				DFS(i, b);
			}
		}
	}
}
